<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Obrađeni podaci</title>

    <script>
    function validateForm() {
        var naslov = document.getElementById("naslov").value;
        var kratki_sadrzaj = document.getElementById("kratki_sadrzaj").value;
        var tekst = document.getElementById("tekst").value;
        var slika = document.getElementById("slika").value;
        var kategorija = document.getElementById("kategorija").value;
        var error = false;

        if (naslov.length < 5 || naslov.length > 30) {
            document.getElementById("naslov").style.borderColor = "red";
            error = true;
        } else {
            document.getElementById("naslov").style.borderColor = "";
        }

        if (kratki_sadrzaj.length < 10 || kratki_sadrzaj.length > 100) {
            document.getElementById("kratki_sadrzaj").style.borderColor = "red";
            error = true;
        } else {
            document.getElementById("kratki_sadrzaj").style.borderColor = "";
        }

        if (tekst.trim() === "") {
            document.getElementById("tekst").style.borderColor = "red";
            error = true;
        } else {
            document.getElementById("tekst").style.borderColor = "";
        }

        if (slika === "") {
            document.getElementById("slika").style.borderColor = "red";
            error = true;
        } else {
            document.getElementById("slika").style.borderColor = "";
        }

        if (kategorija === "") {
            document.getElementById("kategorija").style.borderColor = "red";
            error = true;
        } else {
            document.getElementById("kategorija").style.borderColor = "";
        }

        if (error) {
            document.getElementById("error-message").innerHTML = "Molimo ispravno popunite formu.";
            return false;
        }
    }
</script>

</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $naslov = $_POST['naslov'];
            $sazetak = $_POST['sazetak'];
            $tekst = $_POST['tekst'];
            $kategorija = $_POST['kategorija'];
            $obavijest = isset($_POST['obavijest']) ? 'Da' : 'Ne';

            echo '<div class="obradjeni-podaci">';
            echo '<h3><strong>Kategorija:</strong> ' . $kategorija . '</h3>';
            echo '<p><strong>Naslov:</strong> ' . $naslov . '</p>';
            // if (isset($_FILES['slika']) && $_FILES['slika']['error'] === 0) {
            //     $slika = $_FILES['slika']['tmp_name'];
            //     $naziv = $_FILES['slika']['name'];
            //     $destinacija = 'putanja/do/slike/' . $naziv;
            
            //     if (move_uploaded_file($slika, $destinacija)) {
            //         echo 'Slika je uspješno prenesena i spremljena na serveru.';
            //         echo '<br>';
            //         echo '<img src="' . $destinacija . '" alt="Moja slika">';
            //     } else {
            //         echo 'Došlo je do greške prilikom spremanja slike.';
            //     }
            // }
            echo '<p><strong>Sažetak:</strong> ' . $sazetak . '</p>';
            echo '<p><strong>Tekst:</strong> ' . $tekst . '</p>';
            echo '</div>';
        }
        ?>

    </main>
    
    <footer>
        Antonio Stopić - astopic@tvz.hr - 2023
    </footer>
</body>
</html>
