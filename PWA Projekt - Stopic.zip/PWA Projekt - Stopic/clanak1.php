<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Članak 1</title>
</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main class="mainClanak">
        <h2>Vozaču Hitne koji je na Bundeku udario maloljetnike odredili su pritvor, odveli ga u Remetinec</h2>
        <img class="slikaClanak" src="slike/slika1.webp" alt="">
        <div>
            <h3>Pritvor je bio predložen upravo zbog opasnosti od ponavljanja djela, odnosno činjenice da je ranije osuđen zbog prometne nesreće.</h3>
            <br>
            <p>Vozaču (62) Hitne pomoći koji je u srijedu navečer vozilom udario troje maloljetnika na zagrebačkom jezeru Bundek odredili su istražni zatvor zbog opasnosti od ponavljanja djela te ga odveli u Remetinec, piše Jutarnji list.</p>
            <br>
            <p>Njega su ranije doveli na Županijski sud u Velikoj Gorici na ispitivanje, a pritvor je bio predložen upravo zbog opasnosti od ponavljanja djela, odnosno činjenice da je ranije osuđen zbog prometne nesreće.</p>
            <br>
            <p>Njegov odvjetnik Marin Ivanović rekao je kako se klijent osjeća psihički vrlo loše.</p>
            Vozač koji je bio na intervenciji u srijedu navečer je udario troje maloljetnika, a jedan je mladić teško ozlijeđen.
        </div>
        
</main>

<footer>
    Antonio Stopić - astopic@tvz.hr - 2023
</footer>

</body>
</html>