<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Članak 4</title>
</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main class="mainClanak">
        <h2>Rumunji pišu: Uefa bi trebala Ukrajincima oduzeti pobjedu protiv Hrvatske na Euru U-21</h2>
        <img class="slikaClanak" src="slike/slika4.webp" alt="">
        <div>
            <h3>Strahujete li da bi Uefa mogla oduzeti Ukrajini pobjedu nad Hrvatskom?</h3>
            <p>To je pitanje sletjelo izborniku ukrajinske U-21 reprezentacije Ruslanu Rotanu dan uoči okršaja s Rumunjskom. Tema koja je u oba tabora izazvala dosta pažnje. Što, pišu rumunjski mediji, prema pravilima nije dopušteno, odnosno igrači ne smiju igrati dvije utakmice u 48 sati.</p>

            <br>
            <h3>Sport.ro odgovor:</h3>
            <p>"Fifa zahtjeva dva dana odmora između utakmica i potvrdila nam je da ako je igrač u ponedjeljak igrao za A reprezentaciju, nema pravo u srijedu igrati za mladu", navodi Sport.ro.</p>
            <br>
            <h3>Nešto kasnije stigla je i konačna Uefina presuda:</h3>
            <p>HNS je komunicirao s Uefom o navedenoj temi te, prema povratnim informacijama od Uefe, navedeno pravilo ne odnosi se na natjecanja izvan Fifinog kalendara međunarodnih utakmica te ne postoji nikakvo drugo pravilo Uefe i/ili Fife koje zabranjuje nastupanje istog igrača za obje reprezentacije.</p>
        </div>
        
</main>

<footer>
    Antonio Stopić - astopic@tvz.hr - 2023
</footer>

</body>
</html>