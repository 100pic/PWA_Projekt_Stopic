<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Članak 2</title>
</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main class="mainClanak">
        <h2>Ana Brnabić: Srbija je iskreno zainteresirana za razvoj boljih odnosa s Hrvatskom. Važni su</h2>
        <img class="slikaClanak" src="slike/slika2.webp" alt="">
        <div>
            <h3>Ana Brnabić u petak je rekla da je Srbija iskreno zainteresirana za razvijanje i unaprjeđenje odnosa s Hrvatskom s kojom dijeli mnogo toga zajedničkog</h3>
            <br>
            <p>Premijeri dviju vlada sastali su se u Subotici gdje su sudjelovali na otvaranju Hrvatske kuće, novog sjedišta Hrvata u Vojvodini i Srbiji. </p>
            <p>- Srbija smatra da su odnosi s Hrvatskom veoma važni i iskreno, iskreno je zainteresirana za razvijanje sveukupnih odnosa i unaprjeđenja uzajamno korisne suradnje - rekla je u svom govoru u toj prigodi Brnabić.</p>
            <br>
            <p>Dvije zemlje dijele „mnogo toga zajedničkog, nažalost i onog lijepog i onog ružnog“, nastavila je predsjednica vlade Srbije, dodavši kako „nije tajna da nas još uvijek opterećuju teške posljedice zajedničke povijesti“. </p>
            <p>Brnabić je naglasila da su Zagreb i Beograd „intenzivirali dijalog“ te da se samo ove godine održalo šest sastanaka na visokoj i najvišoj razini, što je važno za stvaranje klime za suradnju i rješavanju otvorenih pitanja. </p>
            <br>
            <p>Plenković je u svom govoru rekao kako je s Brnabić razgovarao o „pitanju nestalih, pitanju granice, procesuiranja ratnih zločina i ratnih šteta“, svega onoga što „opterećuje naše odnose desetljećima“. </p>
        </div>
        
</main>

<footer>
    Antonio Stopić - astopic@tvz.hr - 2023
</footer>

</body>
</html>