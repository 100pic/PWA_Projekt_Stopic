<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Počezna</title>
</head>
<body>
    <header>
        <h1>POČETNA</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main>
        <h2>SPORT</h2>
        <section>
            <article>
                <a href="clanak4.php">
                    <img src="slike/slika4.webp" alt="">
                    <div class="okvir">
                        <p>Poslali smo relevantne dokumente klubovima i pitali Uefu za dopuštenje. Te napravili kako mislimo da je najbolje, rekao je ukrajinski izbornik Rotan. HNS je svjestan situacije i čeka Uefin stav</p>
                        <p class="sivi_tekst">Objavljeno prije 12 sati</p>
                    </div>
                </a>
            </article>
            
            <article>
                <a href="clanak5.php">
                    <img src="slike/slika5.webp" alt="">
                    <div class="okvir">
                        <p>Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igrača. Dinamu stiže novo pojačanje iz Istre, ovo su svi novi detalji dogovora:</p> 
                        <p class="sivi_tekst">Objavljeno prije 15 sati</p>
                    </div>
                </a>
            </article>

            <article>
                <a href="clanak6.php">
                    <img src="slike/slika6.webp" alt="">
                    <div class="okvir">
                        <p class="clanak6">Ljetni prijelazni rok u većini europskih liga službeno još nije ni počeo, ali neki klubovi su već sada započeli s jačanjem momčadi za novu sezonu. Sve najnovije transfere pratite na našem portalu</p>
                        <p class="sivi_tekst">Objavljeno prije 19 sati</p>
                    </div>
                </a>
            </article>
        </section>
    </main>

    <footer>
        Antonio Stopić - astopic@tvz.hr - 2023
    </footer>

</body>
</html>
