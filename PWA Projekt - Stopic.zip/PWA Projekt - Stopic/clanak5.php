<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Članak 5</title>
</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main class="mainClanak">
        <h2>Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igrača</h2>
        <img class="slikaClanak" src="slike/slika5.webp" alt="">
        <div>
            <h3>Dinamo želi Monsefa Bakrara! Zagrepčani ga žele na posudbu s pravom otkupa krajem sezone</h3>
            <p>Zagrepčanima se ne sviđa preveliko odugovlačenje u pregovorima s Rijekom i Mariborom oko Matije Frigana i Žana Vipotnika, pa se polako okreću drugim napadačkim opcijama...</p>

            <br>
            <p>Dinamo je u otvorenoj potrazi za novim napadačem. Posljednjih tjedana u maksimirskim kuloarskim spominjali su se Matija Frigan i Žan Vipotnik, ali čelnici "modrih" dali su službenu ponudu za napadača Istre Monsefa Bakrara. Riječ je o 22-godišnjem Alžircu koji je prošle godine za pulskog prvoligaša u 31 nastupu zabio osam golova, tome dodao i tri asista. </p>
            <br>
            <p>Monsef Bakrar bi u Maksimiru imao tri ili četiri puta veću plaću nego u Istri 1961, sam igrač želi doći u Dinamo, dobiti priliku za dokazivanje i na europskoj sceni..</p>
        </div>
        
</main>

<footer>
    Antonio Stopić - astopic@tvz.hr - 2023
</footer>

</body>
</html>