-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2023 at 10:28 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pwa_projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `date` varchar(11) NOT NULL,
  `naslov` varchar(64) NOT NULL,
  `sazetak` text NOT NULL,
  `tekst` text NOT NULL,
  `slika` varchar(64) NOT NULL,
  `kategorija` varchar(64) NOT NULL,
  `arhiva` tinyint(1) NOT NULL,
  `autor` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250 COLLATE=cp1250_croatian_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES

(1, 'NAJNOVIJE VIJESTI', 'Vozaču Hitne koji je na Bundeku udario maloljetnike odredili su pritvor, odveli ga u Remetinec. Pritvor je bio predložen upravo zbog opasnosti od ponavljanja djela', 'Vozaču Hitne koji je na Bundeku udario maloljetnike odredili su pritvor, odveli ga u Remetinec. Pritvor je bio predložen upravo zbog opasnosti od ponavljanja djelaVozaču Hitne koji je na Bundeku udario maloljetnike odredili su pritvor, odveli ga u Remetinec. Pritvor je bio predložen upravo zbog opasnosti od ponavljanja djela', 'slika1.webp', 'NAJNOVIJE VIJESTI', 0),
(2, 'NAJNOVIJE VIJESTI', 'Ana Brnabić u petak je rekla da je Srbija iskreno zainteresirana za razvijanje, održavanje i unaprjeđenje odnosa s Hrvatskom s kojom Srbija dijeli mnogo toga zajedničkog', 'Ana Brnabić u petak je rekla da je Srbija iskreno zainteresirana za razvijanje, održavanje i unaprjeđenje odnosa s Hrvatskom s kojom Srbija dijeli mnogo toga zajedničkog. Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igračaDinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora:', 'slika2.webp', 'NAJNOVIJE VIJESTI', 0),
(3, 'NAJNOVIJE VIJESTI', 'Tragedija kod Dubrovnika: Mladić preminuo prije dolaska hitne, našli ga iscrpljenog. Dojavu je policija dobila oko 23 sata, a mladića su pronašli 200-tinjak metara od prometnice', 'Tragedija kod Dubrovnika: Mladić preminuo prije dolaska hitne, našli ga iscrpljenog. Dojavu je policija dobila oko 23 sata, a mladića su pronašli 200-tinjak metara od prometnice. Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igračaDinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora:', 'slika3.webp', 'NAJNOVIJE VIJESTI', 0),
(4, 'SPORT', 'Poslali smo relevantne dokumente klubovima i pitali Uefu za dopuštenje. Te napravili kako mislimo da je najbolje, rekao je ukrajinski izbornik Rotan. HNS je svjestan situacije i čeka Uefin stav', 'Poslali smo relevantne dokumente klubovima i pitali Uefu za dopuštenje. Te napravili kako mislimo da je najbolje, rekao je ukrajinski izbornik Rotan. HNS je svjestan situacije i čeka Uefin stav. Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igračaDinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora:', 'slika4.jpg', 'SPORT', 0),
(5, 'SPORT', 'Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igračaDinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora:', 'Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igračaDinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora. Dinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora: U suprotnom smjeru trojica igračaDinamu stiže novo pojačanje iz Istre, ovo su detalji dogovora:', 'slika5.webp', 'SPORT', 0),
(6, 'SPORT', 'Ljetni prijelazni rok u većini europskih liga službeno još nije ni počeo, ali neki klubovi su već sada započeli s jačanjem momčadi za novu sezonu. Sve najnovije transfere pratite na našem portalu', 'Ljetni prijelazni rok u većini europskih liga službeno još nije ni počeo, ali neki klubovi su već sada započeli s jačanjem momčadi za novu sezonu. Sve najnovije transfere pratite na našem portalu. Ljetni prijelazni rok u većini europskih liga službeno još nije ni počeo, ali neki klubovi su već sada započeli s jačanjem momčadi za novu sezonu. Sve najnovije transfere pratite na našem portalu', 'Slika6.webp', 'SPORT', 0),

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `surname` varchar(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1250 COLLATE=cp1250_croatian_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `surname`, `username`, `password`, `level`) VALUES
(1, 'Antonio', 'Stopić', 'admin', '$2y$10$a20XfKvzCUXu4rPrD7oaV.f4zILUUDOIYa7zGma6cwsocs52dX.hq', 1),
(2, 'gost', 'gost', 'gost', '$2y$10$OHA1JB0VymmgAsmAui0Fz.qdTEmLyIJ0n3iqFU.Wfu2nyo0VuZSO6', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username_ix` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
