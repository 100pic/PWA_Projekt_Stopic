<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/6d031afde7.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css" type="text/css">
    <title>Odjava</title>

    <style>
        form > div {
            margin: 20px 0 10px 0;
        }

        form button {
            padding: 5px 20px;
            text-align: center;
        }

        #message{
            margin-top: 10px;   
            font-size: 13px;
        }
    </style>
</head>

<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='#'>ADMINISTRACIJA</a></li>";
                    }
                }
                ?>
            </ul>
        </nav>
    </header>
    <main>
        <form action="#" method="post">
            <div>Želite li se zaista odjaviti?</div>
            <button type="submit" name="logout">Da</button>
        </form>

        <?php
            if (isset($_POST["logout"])) {
                $_SESSION["current_username"] = "";
                $_SESSION["current_level"] = 0;

                echo "<div id='message'>Odjava uspješna.</div>";
            }
        ?>
    </main>
        Antonio Stopić - astopic@tvz.hr - 2023
    <footer>
    </footer>
</body>

</html>