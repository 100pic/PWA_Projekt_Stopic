<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">
    <title>Unos vijesti</title>

</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main>
        <h2>Unos vijesti</h2>
        <form action="skripta.php" method="POST" enctype="multipart/form-data">

            <label for="naslov">Naslov vijesti</label>
            <input type="text" id="naslov" name="naslov" required>
            <span id="naslov_error"></span>

            <label for="sazetak">Kratki sažetak vijesti (do 50 znakova)</label>
            <textarea id="sazetak" name="sazetak" required></textarea>
            <span id="sazetak_error"></span>

            <label for="tekst">Sadržaj vijesti:</label>
            <textarea id="tekst" name="tekst" required></textarea>
            <span id="tekst_error"></span>

            <label for="slika">Slika:</label>
            <input type="file" id="slika" name="slika" accept="image/*" required>
            <span id="slika_error"></span>

            <label for="kategorija">Kategorija vijesti:</label>
            <select id="kategorija" name="kategorija" required>
                <option value="politika">Najnovije vijesti</option>
                <option value="sport">Sport</option>
            </select>
            <span id="kategorija_error"></span>

            <label for="obavijest">Spremiti u arhivu:</label>
            <input type="checkbox" id="obavijest" name="obavijest">
            <span id="obavijest_error"></span>

            <input type="submit" value="Pošalji">
        </form>

        <script src="validacija_unos.js" type="text/javascript"></script>

    </main>

    <footer>
        Antonio Stopić - astopic@tvz.hr - 2023
    </footer>
</body>
</html>
