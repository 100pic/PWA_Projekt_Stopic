<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Članak 3</title>
</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main class="mainClanak">
        <h2>Tragedija kod Dubrovnika: Mladić preminuo prije dolaska hitne, našli ga iscrpljenog</h2>
        <img class="slikaClanak" src="slike/slika3.webp" alt="">
        <div>
            <h3>Dojavu je policija dobila oko 23 sata, a mladića su pronašli 200-tinjak metara od prometnice u brdovitom i šumskom dijelu</h3>
            <p>Policija je u petak navečer, nakon dojave, na području Dračeva sela kod Dubrovnika zatekla jako iscrpljena mladića bez identifikacijskih dokumenata, koji je preminuo prije dolaska hitne pomoći, objavila je u subotu Policijska uprava dubrovačko-neretvanska.</p>
            <br>
            <p>Dojavu je policija dobila oko 23 sata, a mladića su pronašli 200-tinjak metara od prometnice u brdovitom i šumskom dijelu.  </p>
            <br>
            <p>„Očevidom na mjestu događaja ni na tijelu, ni u blizini tijela, nisu pronađeni tragovi koji upućuju da je smrt muškarca nastupila kao posljedica kaznenog djela. Identitet preminulog za sada nije poznat, budući da kod sebe nije imao nikakvih identifikacijskih dokumenata“, navode iz policije. </p>
            <br>
            <p>Dodali su kako je tijelo muškarca prevezeno na Odjel patologije dubrovačke bolnice, gdje će se provesti obdukcija kojom će se utvrditi točan uzrok smrti.</p>
        </div>
        
</main>

<footer>
    Antonio Stopić - astopic@tvz.hr - 2023
</footer>

</body>
</html>