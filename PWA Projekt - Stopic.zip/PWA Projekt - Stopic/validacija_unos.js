document.getElementById("submit").onclick = function (event) {
    var form_validation = true
    var check = true
    var message

    var naslov = document.getElementById("naslov")
    var sazetak = document.getElementById("sazetak")
    var tekst = document.getElementById("tekst")
    var slika = document.getElementById("slika")
    var kategorija = document.getElementById("kategorija")

    if (naslov.value != "") {
        if (naslov.value.length < 5 || naslov.value.length > 50) {
            message = "Naslov mora imati 5 do 30 znakova!"

            check = false
        }
    }
    else{
        message = "Naslov ne smije biti prazan!"

        check = false
    }

    if (check == false) {
        document.getElementById("naslov_error").innerHTML = message
        naslov.style.border = "1px solid red"

        form_validation = false
    }

    check = true
    if (sazetak.value != "") {
        if (sazetak.value.length < 10 || sazetak.value.length > 100) {
            message = "Kratki sadržaj mora imati od 10 do 100 znakova!"

            check = false
        }
    }
    else{
        message = "Kratki sadržaj ne smije biti prazan!"

        check = false
    }

    if (check == false) {
        document.getElementById("short-tekst_error").innerHTML = message
        sazetak.style.border = "1px solid red"

        form_validation = false
    }

    if (tekst.value == "") {
        document.getElementById("tekst_error").innerHTML = "Sadržaj ne smije biti prazan!"
        tekst.style.border = "1px solid red"

        form_validation = false
    }

    // if (slika.value == "") {
    //     document.getElementById("slika_error").innerHTML = "Upload slike je potreban!"
    //     slika.style.border = "1px solid red"

    //     form_validation = false
    // }

    if (kategorija.value == "") {
        kategorija.style.border = "1px solid red"
        document.getElementById("news-category_error").innerHTML = "Morate odabrati jednu od kategorija obavijesti!"

        form_validation = false
    }

    if (form_validation == false) {
        event.preventDefault()
    }
}