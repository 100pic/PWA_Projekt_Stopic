<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Počezna</title>
</head>
<body>
    <header>
        <h1>POČETNA</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main>
        <h2>Najnovije vijesti</h2>
        <section>
            <article>
                <a href="clanak1.php">
                    <img src="slike/slika1.webp" alt="">
                    <div class="okvir">
                        <p>Vozaču Hitne koji je na Bundeku udario maloljetnike odredili su pritvor, odveli ga u Remetinec. Pritvor je bio predložen upravo zbog opasnosti od ponavljanja djela</p>
                        <p class="sivi_tekst">Objavljeno prije 2 sata</p>
                    </div>
                </a>
            </article>
                
                
            <article>
                <a href="clanak2.php">
                    <img src="slike/slika2.webp" alt="">
                    <div class="okvir">
                        <p>Ana Brnabić u petak je rekla da je Srbija iskreno zainteresirana za razvijanje, održavanje i unaprjeđenje odnosa s Hrvatskom s kojom Srbija dijeli mnogo toga zajedničkog</p> 
                        <p class="sivi_tekst">Objavljeno prije 3 sata</p>
                    </div>
                </a>
            </article>

            <article>
                <a href="clanak3.php">
                    <img src="slike/slika3.webp" alt="">
                    <div class="okvir">
                        <p>Tragedija kod Dubrovnika: Mladić preminuo prije dolaska hitne, našli ga iscrpljenog. Dojavu je policija dobila oko 23 sata, a mladića su pronašli 200-tinjak metara od prometnice</p>
                        <p class="sivi_tekst">Objavljeno prije 6 sati</p>
                    </div>
                </a>
            </article>
        </section>
    </main>

    <footer>
        Antonio Stopić - astopic@tvz.hr - 2023
    </footer>

</body>
</html>
