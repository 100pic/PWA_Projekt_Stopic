<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" type="text/css">

    <title>Članak 6</title>
</head>
<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                        echo "<li><a href='administracija.php'>ADMINISTRACIJA</a></li>";
                    } elseif ($_SESSION["current_username"] == "") {
                        echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                    } elseif ($_SESSION["current_username"] != "") {
                        echo "<li><a href='odjava.php'>ODJAVA</a></li>";
                    }
                } else {
                    echo "<li><a href='prijava.php'>PRIJAVA</a></li>";
                }
                ?>
            </ul>
        </nav>
        <hr>
    </header>

    <main class="mainClanak">
        <h2>Ljetni prijelazni rok u većini europskih liga službeno još nije ni počeo, ali neki klubovi su već sada započeli s jačanjem momčadi za novu sezonu. Sve najnovije transfere pratite na našem portalu</h2>
        <img class="slikaClanak" src="slike/slika6.webp" alt="">
        <div>
            <h3>KOULIBALY U AL HILALU</h3>
            <p>Saudijska liga nastavlja dovoditi jaka europska imena. Senegalac Kalidou Koulibaly (32) novi je igrač Al Hilala u iduće tri sezone, a Chelsea će na njemu zaraditi 23 milijuna eura.</p>
            <p>U međuvremenu, isti je klub pokušao dovesti Massilimiliana Allegrija kao novog trenera, ali je odbio plaću od 20 milijuna eura. Želi ostati u Juventusu.</p>

            <br>
            <h3>JOŠKO SE DOGOVORIO SA CITYJEM</h3>
            <p>Manchester City uskoro će predstaviti Matea Kovačića kao novog 'građanina', a dolasku u momčad Pepa Guardiole sve je bliže i Joško Gvardiol (21). </p>
            <p>Španjolski trener obožava Joška i inzistira na dolasku drugog Hrvata u istom prijelaznom roku, a Fabrizio Romano javlja kako je City već dogovorio osobne uvjete s igračem, Englezi se sad još samo moraju dogovoriti s Leipzigom oko visine odštete.</p>
            <br>
            <h3>BARCELONA ŽELI BROZOVIĆA</h3>
            <p>Marcelo Brozović (30) bio je na korak od dogovora sa saudijskim Al Nassrom, ali od konačnog dogovora još nema ništa. U priču se uplela i Barcelona koja bi dovela hrvatskog reprezentativca. Problem je, dakako, odšteta. Katalonci su ponudili 15 milijuna za veznjaka "vatrenih", piše Sport, a Inter traži više od 20 milijuna.</p>
        </div>
    </main>

    <footer>
        Antonio Stopić - astopic@tvz.hr - 2023
    </footer>

</body>
</html>