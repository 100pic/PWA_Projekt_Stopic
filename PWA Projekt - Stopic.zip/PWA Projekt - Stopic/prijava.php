<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/6d031afde7.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css" type="text/css">
    <title>Prijava</title>

    <style>
        form {
            margin-top: 10px;
        }

        form>div {
            margin-bottom: 20px;
        }

        form input {
            display: block;
            width: 25%;
            margin-top: 5px;
            background-color: rgb(249, 249, 249);
            border: 1px solid grey;
            border-radius: 5px;
            padding: 5px;
        }

        form button {
            padding: 5px;
            text-align: center;
            width: 10%;
        }

        #reg {
            font-size: 13px;
            color: blue;
        }

        #message {  
            margin-top: 10px;
            font-size: 13px;
        }

        form a:link, a:visited{
            text-decoration: none;
            color: blue;
        }

        form a:hover{
            text-decoration: underline;
        }

        main span {
            display: block;
            width: fit-content;
            color: red;
            font-size: 12px;
            margin-top: 5px;
        }
    </style>

<body>
    <header>
        <h1>L'OBS</h1>
        <nav>
            <ul>
                <li><a href="index.php">POČETNA</a></li>
                <li><a href="unos.php">UNOS</a></li>
                <li><a href="najnovijevijesti.php">NAJNOVIJE VIJESTI</a></li>
                <li><a href="sport.php">SPORT</a></li>
                <li><a href="prijava.php">PRIJAVA</a></li>  
                <?php
                if (isset($_SESSION["current_level"])) {
                    if ($_SESSION["current_level"] == 1) {
                        echo "<li><a href='#'>ADMINISTRACIJA</a></li>";
                    }
                }
                ?>
            </ul>
        </nav>
    </header>
    <main>
        <form action="#" method="post" enctype="multipart/form-data">
            <div>
                <label for="username">Korisničko ime:</label>
                <input type="text" name="username" id="username">
                <span id="username_error"></span>
            </div>
            <div>
                <label for="password">Lozinka:</label>
                <input type="password" name="password" id="password">
                <span id="password_error"></span>
            </div>
            <div id="reg">
                <a href="registracija.php">Nemate račun? Registirajte se ovdje.</a>
            </div>
            <button type="submit" name="login" id="login">Prijava</button>
            <script src="validacija_prijava.js" type="text/javascript"></script>
        </form>
        <?php
        if (isset($_POST["login"])) {
            if ($_POST["username"] != "" && $_POST["password"] != "") {
                include "connect.php";

                $username = $_POST["username"];

                $query = "SELECT username, password, level FROM users WHERE username = ?;";

                $stmt = mysqli_stmt_init($dbc);
                if (mysqli_stmt_prepare($stmt, $query)) {
                    mysqli_stmt_bind_param($stmt, "s", $username);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_store_result($stmt);
                }

                if (mysqli_stmt_num_rows($stmt) == 0) {
                    $message = "Korisnik s tim korisničkim imenom ne postoji!";
                    $color = "red";
                } else {
                    $password = $_POST["password"];
                    mysqli_stmt_bind_result($stmt, $username_check, $password_check, $level_check);
                    mysqli_stmt_fetch($stmt);

                    
                    if (password_verify($password, $password_check)) {
                        $color = "black";

                        if ($level_check == 1) {
                            $message = "Dobro došli " . $username . ". Vi imate administratorske ovlasti.";
                        } else {
                            $message = "Dobro došli " . $username . ".";
                        }

                        $_SESSION["current_username"] = $username;
                        $_SESSION["current_level"] = $level_check;
                    } else {
                        $message = "Netočna lozinka!";
                        $color = "red";
                    }
                }

                echo "<div id='message' style='color: $color;'>$message</div>";

                mysqli_close($dbc);
            }
        }
        ?>
    </main>
    <footer>
    Antonio Stopić - astopic@tvz.hr - 2023
    </footer>
</body>

</html>